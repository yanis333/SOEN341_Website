<?php 

include("../config/db_server.php");
$mysqli = new DB();
printf("ok");
$from = 0;
$to = 30;
$query = "SELECT title, description, user FROM questionlog LIMIT ?,?";
$result = $mysqli->prepare($query);
$result->bind_param('ii', $from, $to);
$result->execute();

$result->bind_result($title, $description, $user);
/* fetch values */
while ($result->fetch())
	{
	$question[] = array(
		'title' => $title,
		'description' => $description,
		'user' => $user,
	);
    }
    
    echo json_encode($question);
/* close statement */
$result->close();
/* close connection */
$mysqli->close();

?>