<!DOCTYPE html>
<html>
<head>
    <title>Main Page</title>
    <meta http-equiv="Content-Type" content="text/html;" charset="utf-8" />
    <link rel="stylesheet" type="text/css" href="login.css">
 <link rel="stylesheet" href="../Jqwidjets/jqwidgets/styles/jqx.base.css" type="text/css" />
<link rel="stylesheet" href="../Jqwidjets/jqwidgets/styles/jqx.classic.css" type="text/css" />
<script type="text/javascript" src="../Jqwidjets/scripts/jquery-1.11.1.min.js"></script>
<script type="text/javascript" src="../Jqwidjets/jqwidjets/jqxcore.js"></script>
<script type="text/javascript" src="../Jqwidjets/jqwidjets/jqxdata.js"></script>
<script type="text/javascript" src="../Jqwidjets/jqwidjets/jqxbuttons.js"></script>
<script type="text/javascript" src="../Jqwidjets/jqwidjets/jqxscrollbar.js"></script>
<script type="text/javascript" src="../Jqwidjets/jqwidjets/jqxmenu.js"></script>
<script type="text/javascript" src="../Jqwidjets/jqwidjets/jqxgrid.js"></script>
    <style>
        .questionsindexphp{
            border:1px solid black;
            margin-top:2%;
            display:grid;
            flex: 1 1 80%;
        }
        .questionOptions{   display:flex;
            justify-content: space-between;


        }
        .centerofindexphp{
            display:flex;
            flex-direction:column;
            border:1px black;
            flex:0 1 50%;

        }
        .contentindexphp{
            margin-top:2%;
            display:flex;
            justify-content: center;
            height:435px; /* somehow cant put a % */

            border:1px red;
        }


    </style>

<script type="text/javascript">
$(document).ready(function () {
    // prepare the data
    var source ={
        datatype: "json",
        datafields: [{ name: 'title' },{ name: 'description' },{ name: 'user' },],
        url: '../Controller/data.php'
    };
    $("#questions").jqxGrid({
        source: source,
        theme: 'classic',
        columns: [{ text: 'title', datafield: 'title', width: 250 },{ text: 'description', datafield: 'description', width: 150 },{ text: 'user', datafield: 'user', width: 180 }]
    });
});
</script>
</head>



<body>
<?php include('header.php'); ?>




<div id="content" class="contentindexphp">

    <div id = "center" class="centerofindexphp">

        <div id="questionOptions" class="questionOptions">

            <div id="search" >Search:<input type=text placeholder="Working on remote search" disabled></div>
            <div id="add" onclick="window.location.href='add.php'"><button >add</button></div>

        </div>
        <div id= "questions" >
        </div>
    </div>
</div>

</body>

</html>